﻿using Interfaces;
using System;

namespace Services
{
    public class ExecutionService : IExecutionService
    {
        private readonly ISavingService _savingService;
        private readonly IAddingService _addingService;
        private readonly ICheckingService _checkingService;
        private readonly IPublishService _publishService;

        public ExecutionService(ISavingService savingService, 
            IAddingService addingService, 
            ICheckingService checkingService, 
            IPublishService publishService)
        {
            _savingService = savingService;
            _addingService = addingService;
            _checkingService = checkingService;
            _publishService = publishService;
        }
        public void Execution(string message, int a)
        {
            _savingService.Saving(message);
            _addingService.Adding(a);
            _checkingService.Checking(message);
            _publishService.Publishing(message);
        }
    }
}
