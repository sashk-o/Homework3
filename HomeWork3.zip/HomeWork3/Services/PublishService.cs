﻿using Interfaces;
using System;

namespace Services
{
    public class PublishService : IPublishService
    {
        public void Publishing(string article)
        {
            Console.WriteLine($"Article to publish is: {article}");
        }
    }
}
