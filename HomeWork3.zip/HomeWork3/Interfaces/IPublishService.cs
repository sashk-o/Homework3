﻿namespace Interfaces
{
    public interface IPublishService
    {
        void Publishing(string article);
    }
}
