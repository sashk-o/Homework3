﻿namespace Interfaces
{
    public interface IExecutionService
    {
        void Execution(string message, int a);
    }
}
