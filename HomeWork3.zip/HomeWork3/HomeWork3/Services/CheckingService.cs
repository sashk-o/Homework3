﻿using Interfaces;
using System;

namespace Services
{
    public class CheckingService : ICheckingService
    {
        public void Checking(string message)
        {
            if (message.Contains('s'))
            {
                Console.WriteLine($"{message} contains symbol 's'");
            }
            else
            {
                Console.WriteLine($"{message} does not contain symbol 's'");
            }
        }
    }
}
