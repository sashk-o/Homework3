﻿using System;
using Interfaces;

namespace Services
{
    public class AddingService : IAddingService
    {
        public void Adding(int a)
        {
            Console.WriteLine($"The result of adding: {10 + a}");
        }
    }
}
