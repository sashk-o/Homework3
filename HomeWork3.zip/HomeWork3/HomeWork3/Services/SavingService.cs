﻿using Interfaces;
using System;

namespace Services
{
    public class SavingService : ISavingService
    {
        public void Saving(string message)
        {
            Console.WriteLine($"It is necessary to publish: {message}");
        }
    }
}
