﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Interfaces;

namespace HomeWork3
{
    public class SavingMiddleware
    {
        private readonly RequestDelegate _requestDelegate;
        
        public SavingMiddleware(RequestDelegate requestDelegate)
        {
            _requestDelegate = requestDelegate;
        }
        public async Task Invoke(HttpContext httpContext)
        {
            var message = httpContext.Request.Query["message"];
            if (message != "")
            {
                await httpContext.Response.WriteAsync(message + "\n");
            }
            await _requestDelegate(httpContext);
            Console.WriteLine("SavingMiddleware finished working!");
        }
    }
}
