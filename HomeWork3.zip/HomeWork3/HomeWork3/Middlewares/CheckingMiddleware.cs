﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace HomeWork3.Middlewares
{
    public class CheckingMiddleware
    {
        private readonly RequestDelegate _next;
        public CheckingMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            var check = context.Request.Query["check"];
            if (check.ToString().Contains('s'))
            {
                await context.Response.WriteAsync($"\"{check}\" contains symbol 's'\n");
            }
            else
            {
                await context.Response.WriteAsync($"\"{check}\" does not contain symbol 's'\n");
            }
            await _next.Invoke(context);
            Console.WriteLine("CheckingMiddleware finished working!");
        }
    }
}
