﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork3.Middlewares
{
    public class AddingMiddleware
    {
        private readonly RequestDelegate _next;
        public AddingMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            var query = context.Request.Query["number"];
            int number = 0;
            try { number = int.Parse(query); }
            catch (Exception e) { Console.WriteLine(e.Message); }
            if (number > 10)
            {
                await context.Response.WriteAsync($"The result of adding 10 and {number} is: { 10 + number}\n");
            }
            else
            {
                await context.Response.WriteAsync($"The result of substracting 10 and {number} is: { 10 - number}\n");
            }
            await _next.Invoke(context);
            Console.WriteLine("AddingMiddleware finished working!");
        }
    }
}
