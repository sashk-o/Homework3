﻿using HomeWork3.Middlewares;
using Microsoft.AspNetCore.Builder;

namespace HomeWork3
{
    public static class MiddlewareExtension
    {
        public static IApplicationBuilder UseSavingMiddleware(this IApplicationBuilder applicationBuilder)
        {
            return applicationBuilder.UseMiddleware<SavingMiddleware>();
        }
        public static IApplicationBuilder UseAddingMiddleware(this IApplicationBuilder applicationBuilder)
        {
            return applicationBuilder.UseMiddleware<AddingMiddleware>();
        }
        public static IApplicationBuilder UseCheckingMiddleware(this IApplicationBuilder applicationBuilder)
        {
            return applicationBuilder.UseMiddleware<CheckingMiddleware>();
        }
    }
}