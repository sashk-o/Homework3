﻿namespace Interfaces
{
    public interface ICheckingService
    {
        void Checking(string message);
    }
}
