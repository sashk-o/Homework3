﻿namespace Interfaces
{
    public interface ISavingService
    {
        void Saving(string message);
    }
}
