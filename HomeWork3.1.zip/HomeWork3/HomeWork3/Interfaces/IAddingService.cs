﻿namespace Interfaces
{
    public interface IAddingService
    {
        void Adding(int a);
    }
}
